@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-agent-v88.ps1" -LocalPayload "%~dp0agent_payload_v88.zip" -ExpectedVersion "13.9.227" -ExpectedBuild "13.9.227-unified-227-ema-rsi-adx-dmi-impulse-reversal-last-mile-advisory-stable-cards" -OpenSiteAfterInstall
if errorlevel 1 (
  echo O instalador nao concluiu. Consulte %LOCALAPPDATA%\SentinelTradingLab\install.log
  pause
  exit /b 1
)
exit /b 0
