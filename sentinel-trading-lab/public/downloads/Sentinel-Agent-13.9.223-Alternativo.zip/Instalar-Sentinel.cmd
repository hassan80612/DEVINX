@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-agent-v88.ps1" -LocalPayload "%~dp0agent_payload_v88.zip" -ExpectedVersion "13.9.223" -ExpectedBuild "13.9.223-native-expiry-reload-reversal-entry-review-card-continuity" -OpenSiteAfterInstall
if errorlevel 1 (
echo ERRO NA INSTALACAO
pause
exit /b 1
)
exit /b 0
