import {wilson} from './forecast-research.mjs';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const sigmoid=x=>1/(1+Math.exp(-clamp(x,-30,30)));
// Predict success of a specific entry, not the direction of every market quote.
// A prediction is frozen before its future outcome updates the model.
export class EntryResearch {
  constructor(saved={}){this.models=saved.version===1?saved.models||{}:{};this.pending=saved.version===1?saved.pending||[]:[];this.outcomes=saved.version===1?saved.outcomes||[]:[];this.unresolved=Number(saved.unresolved||0);this.seen=new Set([...this.pending,...this.outcomes].map(x=>x.id));}
  key({provider,asset,durationMs,kind,side,regime,combo}){return [provider||'unknown',asset,durationMs,kind,side,regime||'unknown',combo].join('|');}
  features(analysis,plan,side){const sign=side==='CALL'?1:-1;return ['micro','momentum','history','location','setup','reversal','acceleration','mtf'].map(k=>clamp(sign*Number(plan?.evidenceFamilies?.[k]?.signal||0),-1,1)).concat([clamp(Number(plan?.agreement||0)/100,0,1),clamp(Number(plan?.dataQuality||0)/100,0,1)]);}
  predict(context,features,baseline=.5){const key=this.key(context),m=this.models[key],probability=m?sigmoid(m.bias+features.reduce((v,x,i)=>v+x*Number(m.weights[i]||0),0)):baseline,rows=this.outcomes.filter(x=>x.key===key&&!x.draw).slice(-300),samples=rows.length,wins=rows.filter(x=>x.won).length,rate=samples?wins/samples:0,interval=wilson(wins,samples),diff=rows.map(x=>x.baselineLoss-x.modelLoss),mean=samples?diff.reduce((v,x)=>v+x,0)/samples:0,variance=samples>1?diff.reduce((v,x)=>v+(x-mean)**2,0)/(samples-1):0,improvementLowerBound=mean-1.96*Math.sqrt(variance/Math.max(samples,1)),sessions=new Set(rows.map(x=>new Date(x.createdAt).toISOString().slice(0,10))).size;
    const payout=Number(context.payout),breakEvenPct=context.payout!=null&&Number.isFinite(payout)&&payout>0&&payout<=1?100/(1+payout):55;
    // A historical aspiration of 10 wins / 2 losses is not a prerequisite
    // for any model to learn. Qualify only from independent forward improvement,
    // sufficient sessions, and a conservative profitability confidence bound.
    const qualified=samples>=120&&sessions>=3&&interval.low>breakEvenPct&&improvementLowerBound>0;
    return {key,probability:qualified?probability:baseline,shadowProbability:probability,qualified,samples,wins,losses:samples-wins,winRate:samples?Math.round(rate*1000)/10:null,interval,sessions,improvementLowerBound,targetWinRate:1000/12,targetMet:samples>=120&&sessions>=3&&interval.low>=1000/12,probabilitySource:qualified?'entry-forward-model':'technical-estimate'};
  }
  record({id,context,features,baseline,price,now,durationMs,prediction}){if(this.seen.has(id))return;this.seen.add(id);this.pending.push({id,key:this.key(context),...context,features,baselineProbability:baseline,modelProbability:prediction.shadowProbability,price,createdAt:now,dueAt:now+durationMs});if(this.pending.length>500)this.unresolved+=this.pending.length-500;this.pending=this.pending.slice(-500);}
  settle(snap,now){const keep=[];for(const p of this.pending){if(now<p.dueAt){keep.push(p);continue;}if(p.provider!==String(snap.provider||'unknown')||p.asset!==String(snap.asset||'').toUpperCase()){if(now-p.dueAt<15000)keep.push(p);else this.unresolved++;continue;}
      const q=(snap.quoteHistory||[]).filter(q=>Number.isFinite(Number(q.price))&&Number(q.price)>0&&Number(q.ts)<=now&&Math.abs(Number(q.ts)-p.dueAt)<=1500).sort((a,b)=>Math.abs(a.ts-p.dueAt)-Math.abs(b.ts-p.dueAt))[0];if(!q){if(now-p.dueAt<15000)keep.push(p);else this.unresolved++;continue;}
      const delta=Number(q.price)-p.price,draw=Math.abs(delta)<=Math.abs(p.price)*1e-10,won=p.side==='CALL'?delta>0:delta<0,y=won?1:0;this.outcomes.push({...p,draw,won:draw?null:won,settledAt:Number(q.ts),settledPrice:Number(q.price),modelLoss:(p.modelProbability-y)**2,baselineLoss:(p.baselineProbability-y)**2});
      if(!draw){const m=this.models[p.key]||{bias:0,weights:p.features.map(()=>0),updates:0},prediction=sigmoid(m.bias+p.features.reduce((v,x,i)=>v+x*m.weights[i],0)),error=prediction-y,rate=.08/Math.sqrt(1+m.updates/100);m.bias=clamp(m.bias-rate*error,-4,4);m.weights=m.weights.map((w,i)=>clamp(w-rate*(error*p.features[i]+.002*w),-4,4));m.updates++;this.models[p.key]=m;}
    }this.pending=keep;this.outcomes=this.outcomes.slice(-6000);this.seen=new Set([...this.pending,...this.outcomes].map(x=>x.id));}
  summary(){const rows=this.outcomes.filter(x=>!x.draw),wins=rows.filter(x=>x.won).length;return {mode:'entry-forward-evaluation',samples:rows.length,wins,losses:rows.length-wins,unresolved:this.unresolved,models:Object.keys(this.models).length,targetWinRate:1000/12,byContext:Object.keys(this.models).map(key=>({key,samples:rows.filter(x=>x.key===key).length,wins:rows.filter(x=>x.key===key&&x.won).length}))};}
  snapshot(){return {version:1,models:this.models,pending:this.pending,outcomes:this.outcomes,unresolved:this.unresolved};}
}
