// Read-only pre-entry risk review. No outcomes, broker calls, timers or direction overrides.
import {historicalPriceStructure} from './historical-price-structure.mjs';
import {levelRoleEvidence} from './level-role-evidence.mjs';
import {assessDirectionalPersistence} from './now-opportunity-engine.mjs';
import {currentQuoteStructureTurn} from './observed-level-sequence.mjs';
export const POLICY=Object.freeze({version:'203-selective-one-minute-admission-v1',scopeMs:[30000,60000],wallPivots:1,wallRejections:2,roomTolerance:1.25,roomRecentMove:.6,dominantEfficiency:.20,rangeEfficiency:.18,weak20Atr:.20,contraryClosedBodyAtr:.12});
export function evaluatePreEntryRisk({side,reason,price,quoteAt,now,durationMs,quoteHistory=[],candles=[],structure=null}){
 const allowed=()=>({blocked:false,reasons:[],details:{}}),d=side==='CALL'?1:side==='PUT'?-1:0;
 if(!d||!POLICY.scopeMs.includes(durationMs)||!(price>0&&quoteAt>0&&quoteAt<=now&&now-quoteAt<=(durationMs===30000?1450:1950)))return allowed();
 const qs=quoteHistory.filter(q=>q.ts<=quoteAt&&(q.receivedAt??q.ts)<=now&&q.price>0);
 if(qs.at(-1)?.ts!==quoteAt||qs.at(-1)?.price!==price)return allowed();
 const epoch=value=>Number(value)>0?(Number(value)<1e12?Number(value)*1000:Number(value)):0;
 const cs=candles.filter(c=>epoch(c.to)<=quoteAt&&(c.receivedAt??0)<=now);
 // The runtime already has the same closed-candle structure. Reuse it when
 // its last closed candle predates the quote; otherwise use the causal prefix.
 const st=structure?.asOf<=quoteAt?structure:historicalPriceStructure({candles:cs,now:quoteAt});
 const before=seconds=>{const target=quoteAt-seconds*1000;
  for(let i=qs.length-1;i>=0;i--)if(qs[i].ts<=target)return target-qs[i].ts<=2500?qs[i].price:null;
  return null;
 };
 // Match the 1m causal proof windows proportionally at 30s.
 // Uses only already received quotes; no delay or new broker polling.
 const evidenceScale=Number(durationMs)===30000?.5:1;
 const prior6=before(6*evidenceScale),prior20=before(20*evidenceScale),prior60=before(60*evidenceScale);
 const tol=st.tolerance||0,atr=st.atr||0;
 const moves={six:prior6===null?null:d*(price-prior6),twenty:prior20===null?null:d*(price-prior20),sixty:prior60===null?null:d*(price-prior60)};
 const reasons=[],details={};
 // 1. An opposing zone remains an obstacle through its far edge. An accelerating
 // quote cannot exempt a candidate from an already measured lack of room.
 if(st.candleLevelMap?.asOf<=quoteAt&&tol>0){
  const needed=moves.six===null?null:Math.max(tol*POLICY.roomTolerance,moves.six*POLICY.roomRecentMove);
  const zone=st.candleLevelMap.levels.find(z=>{
   const role=levelRoleEvidence(z,d===1?'PUT':'CALL');if(role.pivots<POLICY.wallPivots||role.rejections<POLICY.wallRejections)return false;
   const inside=price>=z.low&&price<=z.high,gap=d===1?z.low-price:price-z.high;
   return inside||(needed!==null&&gap>=0&&gap<=needed);
  });
  if(zone){reasons.push('opposing-zone-or-insufficient-room');details.wall={low:zone.low,high:zone.high,level:zone.level,roomNeeded:needed};}
 }
 const state=assessDirectionalPersistence({quoteHistory:qs,quoteAt,now,price,durationMs});
 // 2. A fast two-quote bounce against a dominant observed leg needs an
 // independently observable local higher-low/lower-high structure change.
 // Keep the proven 30s fast-structure reversal path: unlike a 1m
 // opposing leg it has already passed dedicated micro-turn/pivot guards.
 // Additional 30s wall/weak-breakout risk checks still run below.
 if(durationMs===60000&&reason==='confirmed-fast-level-reversal'&&state.side&&state.side!==side&&state.efficiency>=POLICY.dominantEfficiency){
  const turn=currentQuoteStructureTurn({quoteHistory:qs,quoteAt,now,price,side,durationMs});
  if(!turn){reasons.push('fast-reversal-against-dominant-leg-without-structure-change');details.counterLeg=state;}
 }
 // 3. A small historical-level breakout in a low-efficiency 20s path is not
 // enough when BOTH the completed candle and the past minute oppose its side.
 const last=cs.filter(c=>epoch(c.to)-epoch(c.from)===60000).sort((a,b)=>epoch(a.to)-epoch(b.to)).at(-1);
 if(reason==='historical-level-breakout'&&last&&atr>0&&moves.twenty!==null&&moves.sixty!==null&&
    state.efficiency<POLICY.rangeEfficiency&&d*(last.close-last.open)<=-atr*POLICY.contraryClosedBodyAtr&&
    moves.sixty<0&&moves.twenty<=atr*POLICY.weak20Atr){
  reasons.push('minor-breakout-without-closed-candle-and-minute-support');details.breakout={moves,lastClosedOpen:last.open,lastClosedClose:last.close,efficiency:state.efficiency};
 }
 return {blocked:reasons.length>0,reasons,details};
}

const labels={
 'opposing-zone-or-insufficient-room':'Zona contrária ainda não superada; entrada sem espaço.',
 'fast-reversal-against-dominant-leg-without-structure-change':'Reversão rápida contra fluxo dominante sem mudança estrutural.',
 'minor-breakout-without-closed-candle-and-minute-support':'Rompimento local sem sustentação da vela fechada e do último minuto.',
 'one-minute-observed-range-turn':'Virada em faixa sem validação fora da amostra para 60 s.',
 'one-minute-confirmed-level-rejection':'Rejeição de nível com prova de 60 s em revisão; entrada suspensa.'
};
export function reviewPreEntryRisk({candidate,original,...input}={}){
 if(candidate?.ready!==true||!POLICY.scopeMs.includes(Number(input.durationMs))||
   !['CALL','PUT'].includes(candidate.side)||Number(candidate.observedAt)!==Number(input.quoteAt)||
   Number(candidate.entryPrice)!==Number(input.price))return candidate;
 // The retrospective sample was weakest for range turns and confirmed
 // historical-level rejections. Keep the gate narrow: the structural-turn
 // and failed-breakout families remain admitted, and no other expiry changes.
 const matchingOriginal=original?.reason===candidate.reason&&original?.side===candidate.side&&
  Number(original.observedAt)===Number(candidate.observedAt)&&
  Number(original.entryPrice)===Number(candidate.entryPrice);
 const proof=candidate.priceStructure?.reactionProof||
  (matchingOriginal?original.priceStructure?.reactionProof:null);
 const reviewedDuration=Number(input.durationMs);
 // A historical range label alone is not proof. However, an INDEPENDENT
 // same-tick structure-change/reaction confirmation should not be delayed
 // by this retrospective range-specific veto. All ordinary risk checks below
 // (opposing wall, live turn, candle support) still execute.
 const structural=candidate.priceStructure?.confirmedReversal||
   candidate.priceStructure?.observedSequence?.structureChange;
 const independentTurn=structural?.side===candidate.side&&
   Number(structural.confirmedAt)>0&&
   Number(structural.confirmedAt)<=Number(input.quoteAt)&&
   Number(input.quoteAt)-Number(structural.confirmedAt)<=
    (reviewedDuration===30000?1450:1950);
 const independentProof=proof?.confirmed===true&&
   proof?.side===candidate.side&&Number(proof.durationMs)===reviewedDuration;
 const selectiveRule=candidate.reason==='closed-range-extreme-reversal-confirmed'&&
   candidate.regime==='observed-range-turn'&&
   !(independentTurn&&independentProof)?'one-minute-observed-range-turn':
  candidate.reason==='historical-level-rejection'&&proof?.confirmed===true&&
   proof?.kind==='sustained-level-reversal'&&proof?.side===candidate.side&&
   Number(proof.durationMs)===reviewedDuration?
    'one-minute-confirmed-level-rejection':null;
 // Mirror the 1m conservative rejection policy on 30s. This is not a
 // cooldown: only the actual unsupported setup is rejected.
 if(selectiveRule)return {...candidate,ready:false,side:null,provisionalSide:candidate.side,
  reason:labels[selectiveRule],entryRisk:{kind:'selective-one-minute-admission',blocked:true,
   reasons:[selectiveRule],details:{durationMs:reviewedDuration,proofKind:proof?.kind||null}}};
 const review=evaluatePreEntryRisk({...input,side:candidate.side,reason:candidate.reason});
 if(!review.blocked)return candidate;
 return {...candidate,ready:false,side:null,provisionalSide:candidate.side,
  reason:labels[review.reasons[0]],entryRisk:{kind:'pre-entry-risk-review',...review}};
}
