import {packExecutor,unpackExecutor,dispatchExecutor} from './executor-remote.mjs';
import {SignalExecutor} from './signal-executor.mjs';
import {BrokerUiExecutor} from './broker-ui-executor.mjs';
import {marketDiagnostic} from './market-diagnostic.mjs';
import {runtimeMarketFromLive} from './runtime-market.mjs';
import {LatestQuoteScheduler} from './latest-quote-scheduler.mjs';
import {LatestOverlayScheduler} from './latest-overlay-scheduler.mjs';
import {lightweightOverlayView} from './lightweight-overlay-view.mjs';
import {shouldDiscardVnextFrame} from './vnext-frame-visibility.mjs';
import http from 'node:http';
import {readFile,writeFile,mkdir,rename,chmod} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {randomBytes} from 'node:crypto';
import {DemoTradingRuntime} from '../src/core/runtime.mjs';
import {EncryptedSessionVault} from './session-vault.mjs';
import {HttpBrowserDriver} from './browser-driver.mjs';
import {LocalPlaywrightDriver} from './local-playwright-driver.mjs';
import {IqOptionAdapter} from './adapters/iq-option.mjs';
import {ExnovaAdapter} from './adapters/exnova.mjs';
import {SentinelRemoteRelay} from './remote-relay.mjs';
import {dashboardTransportState} from './remote-status.mjs';
import {analystSnapshot} from './live-bridge.mjs';
import {SignedLiveBridge} from './signed-live-bridge.mjs';
import {MarketJournal} from './market-journal.mjs';

import {VERSION,BUILD} from './release.mjs';
import {RUNTIME_OPTIONS} from './release.mjs';
const HOST=process.env.SENTINEL_WORKER_HOST||'127.0.0.1';
const PORT=Number(process.env.SENTINEL_WORKER_PORT||8787);
const TOKEN=process.env.SENTINEL_WORKER_TOKEN||'';
const STATE_FILE=resolve(process.env.SENTINEL_STATE_FILE||'worker/data/state.json');
const VAULT_FILE=resolve(process.env.SENTINEL_SESSION_VAULT_FILE||'worker/data/broker-sessions.json.enc');
const SECRET_FILE=resolve(process.env.SENTINEL_LOCAL_SECRET_FILE||'worker/data/local-agent.secret');
if(HOST!=='127.0.0.1'&&HOST!=='localhost'&&!TOKEN)throw new Error('SENTINEL_WORKER_TOKEN is required when exposing worker beyond loopback');

const recordMarketJournal=process.env.SENTINEL_MARKET_JOURNAL==='1';
const marketJournal=new MarketJournal({directory:resolve(dirname(STATE_FILE),'market-history'),release:{version:VERSION,build:BUILD,runtime:RUNTIME_OPTIONS}});
let journalAnalysisAt=0;
if(recordMarketJournal)setInterval(()=>marketJournal.flush(),2000).unref();
const runtime=new DemoTradingRuntime({...RUNTIME_OPTIONS,enableVNext:true,seed:Number(process.env.SENTINEL_DEMO_SEED||20261002),balance:Number(process.env.SENTINEL_DEMO_BALANCE||10000)});
const driver=process.env.SENTINEL_BROWSER_DRIVER_URL?new HttpBrowserDriver({baseUrl:process.env.SENTINEL_BROWSER_DRIVER_URL,token:process.env.SENTINEL_BROWSER_DRIVER_TOKEN||''}):new LocalPlaywrightDriver({dataDir:process.env.SENTINEL_BROWSER_PROFILE_DIR||'worker/data/browser-profiles'});
const overlayUpdates=new LatestOverlayScheduler((provider,data)=>driver.updateOverlay?.(provider,data));
const brokers={iq_option:new IqOptionAdapter({driver}),exnova:new ExnovaAdapter({driver})};
const loginStates={iq_option:null,exnova:null};
let activeProvider=null;
const executorSettingsFile=resolve(dirname(STATE_FILE),'executor-settings.json');
const executorTargetsFile=resolve(dirname(STATE_FILE),'executor-targets.json');
function executionContext(){const st=activeProvider?driver.state?.(activeProvider):null;return{provider:activeProvider,activeId:st?.activeId,asset:st?.symbol,state:runtime.stateName,licensed:accessLeaseValid(),durationMs:Number(runtime.settings.orderDurationMs),engine:runtime.settings.engine,analysis:runtime.lastResult?.analysis,quote:st?.quote,quoteAt:st?.lastQuoteAt,quoteHistory:st?.quoteHistory||[],brokerBalance:activeProvider?driver.accountBalanceSnapshot?.(activeProvider)||null:null};}
const uiExecutor=new BrokerUiExecutor(driver,{onSent:(rid,id)=>executor.sent(rid,id),onAccepted:event=>executor.accepted(event),onRejected:event=>executor.rejected(event),onSettlement:event=>executor.settle(event),onUnexpectedOrder:()=>{if(executor.enabled){executor.hardHoldReason='operação externa detectada · confira a conta';executor.suspensionReason=executor.hardHoldReason;executor.message='Ligado · suspenso por segurança: '+executor.hardHoldReason;}}});
const executor=new SignalExecutor({driver:uiExecutor,context:executionContext});
// An analyst-confirmed NOW decision must not wait for the rest of the heavy
// cycle (research/dashboard/status). The post-tick pulse is deduplicated.
runtime.onNowOpportunity=anchor=>{
 try{executor.pulse(anchor);}
 catch(e){executor.message='Falha ao entregar sinal imediato: '+String(e?.message||e);}
};
// Balance-changed is already observed passively from the live broker.
 // Hand it to the risk engine immediately instead of waiting for next 400ms tick.
 // Do not request balances or rescan the browser; forecast is untouched.
driver.setBalanceUpdateHandler?.((provider,balance)=>{
 if(provider===activeProvider)executor.observeBalance(balance);
});
executor.onBatchReleased=batch=>uiExecutor.retireUnidentifiedBatch(batch);
let executorSettingsWrite=Promise.resolve();
async function executorAction(action,payload={}){
 if(action==='executor-stop'){const old=executor.pending;const result=executor.stop('Parado por você',{reset:true});if(old)uiExecutor.retireUnidentifiedBatch(old);return{ok:true,message:result.message};}
 assertLicensedAccess();
 if(action==='executor-map'||action==='executor-map-save'){
  if(executor.enabled||executor.arming||executor.pending||executor.executing)throw Error('Pare o bot e aguarde a entrada encerrar antes de mapear.');
  if(action==='executor-map'){await uiExecutor.beginCalibration(activeProvider);return{ok:true,message:'Indique CALL e depois PUT no painel da corretora. Os cliques de indicação não operam.'};}
  const bindings=await uiExecutor.saveBinding(activeProvider,payload.binding);await mkdir(dirname(executorTargetsFile),{recursive:true});await writeFile(executorTargetsFile+'.tmp',JSON.stringify(bindings),{mode:0o600});await rename(executorTargetsFile+'.tmp',executorTargetsFile);
  executor.message='CALL/PUT mapeados para '+(activeProvider==='iq_option'?'IQ Option':'Exnova')+' · pronto para ligar';return{ok:true,message:executor.message};
 }
 if(action==='executor-config'){executor.configure(payload.patch||{});const serialized=JSON.stringify(executor.config);executorSettingsWrite=executorSettingsWrite.catch(()=>{}).then(async()=>{await mkdir(dirname(executorSettingsFile),{recursive:true});await writeFile(executorSettingsFile+'.tmp',serialized,{mode:0o600});await rename(executorSettingsFile+'.tmp',executorSettingsFile);});await executorSettingsWrite;return{ok:true,message:'Configuração do bot aplicada'};}
 if(action==='executor-start'){try{if(typeof driver.setExecutionObserver!=='function')throw Error('Atualize o Agent local para confirmar as ordens.');driver.setExecutionObserver((provider,frame,direction)=>uiExecutor.observe(provider,frame,direction));await executor.start();}catch(e){throw e;}return{ok:true,message:executor.message};}
 throw Error('Comando do bot inválido.');
}

function remoteExecutorState(){return unpackExecutor(packExecutor({...executor.status(),provider:activeProvider,updatedAt:Date.now()}));}

function chooseLive(){
  if(activeProvider){
    const activePeek=driver.peek?.(activeProvider);
    if(activePeek?.updatedAt&&activePeek.open===false)activeProvider=null
  }
  const order=activeProvider?[activeProvider,...['iq_option','exnova'].filter(x=>x!==activeProvider)]:['iq_option','exnova'];
  for(const k of order){
    const b=brokers[k],peek=driver.peek?.(k),m=driver.liveStatus?.(k);
    if(peek?.updatedAt&&peek.open===false)continue;
    if(b?.connected&&m&&(m.balance!=null||m.quote!=null||m.candles?.length)){
      if(activeProvider!==k)activeProvider=k;
      return{k,m}
    }
  }
  return null
}
function syncRuntimeMarket(){const live=chooseLive();if(!live){runtime.setExternalMarket?.(null);runtime.setExecutionBroker?.(null);return null}const {k,m}=live;const status=String(m.marketStatus||'').toLowerCase(),unresolvedSwitch=status==='switching'&&!m.validatedSymbol&&!m.symbol;const screenSymbol=m.validatedSymbol||m.symbol||m.uiSymbol||(unresolvedSwitch?'':runtime.settings.asset),brokerMode=String(m.mode||'').toLowerCase();runtime.setExternalMarket?.(runtimeMarketFromLive(k,m,screenSymbol));runtime.setExecutionBroker?.(brokers[k]);if(recordMarketJournal)marketJournal.market(runtime.externalMarket,runtime.settings);if(screenSymbol)runtime.settings.asset=screenSymbol;if(['demo','real'].includes(brokerMode)&&runtime.settings.mode!==brokerMode)runtime.setMode(brokerMode,'broker');return live}
async function localSecret(){if(process.env.BROKER_SESSION_ENCRYPTION_KEY)return process.env.BROKER_SESSION_ENCRYPTION_KEY;try{return(await readFile(SECRET_FILE,'utf8')).trim()}catch(e){if(e?.code!=='ENOENT')throw e}await mkdir(dirname(SECRET_FILE),{recursive:true});const secret=randomBytes(32).toString('base64url');await writeFile(SECRET_FILE,secret,{encoding:'utf8',mode:0o600});await chmod(SECRET_FILE,0o600).catch(()=>{});return secret}
const vault=new EncryptedSessionVault({secret:await localSecret(),file:VAULT_FILE});await vault.load();for(const [name,adapter] of Object.entries(brokers))adapter.attachSessionRef(vault.get(name));
const remoteRelay=new SentinelRemoteRelay({version:VERSION});await remoteRelay.init();
// Capability rotates on every Agent start; only authenticated status requests
// reveal it. No Supabase database record is written per live quotation.
const liveTopic='realtime:sentinel-'+randomBytes(24).toString('hex');
const liveSignatureKey=randomBytes(32).toString('hex');
const liveBridge=new SignedLiveBridge(liveTopic,liveSignatureKey,{onViewer:()=>{void publishLiveFrame()}});
liveBridge.start();
let livePublishBusy=false,lastLiveSentDecisionKey='',lastLiveSourceEventKey='';
async function publishLiveFrame(){
  if(livePublishBusy||!liveBridge.hasViewer()||runtime.stateName!=='running')return;
  // Inspect only the already-computed local state. No extra analysis, broker
  // reads or database queries are needed to prioritize a changed decision.
  const op=runtime.lastResult?.analysis?.operationalSignal||{};
  const scenario=op.scenario||{},alert=op.subanalyst?.alert||{};
  const liveForecast=runtime.lastResult?.analysis?.vnext?.receipt||null;
  const mobileEntry=runtime.lastResult?.analysis?.vnext?.futureEntryAnchor||null;
  const pcWindow=runtime.lastResult?.analysis?.vnext?.opportunityWindow||null;
  // The start/end of EVERY PC window is a first-class real-time transition,
  // even when both old and new windows are still in 'scanning' phase.
  // A NEW pinned future-entry clock must bypass routine quote pacing.
  const decisionKey=[runtime.settings.asset,runtime.settings.forecastMode,runtime.settings.engine,runtime.settings.orderDurationMs,
    liveForecast?.side,mobileEntry?.issuedAt,mobileEntry?.entryAt,mobileEntry?.side,
    mobileEntry?.phase,mobileEntry?.entryTriggeredAt,
    pcWindow?.phase,pcWindow?.windowStartedAt,pcWindow?.windowEndsAt,
    scenario.side,scenario.status,scenario.closed,
    op.side,op.state,op.ready,op.actionable,op.activeUntil,
    alert.side,alert.trigger,alert.testing,op.subanalyst?.status].join('|');
  const urgent=decisionKey!==lastLiveSentDecisionKey;
  // Phase/immutable boundary/confirmed trigger are source events, not quote
  // refreshes. Deliver these without a second half-second wait. Everything
  // else retains the original pacing and 3000-byte bound.
  const sourceEventKey=[
    runtime.settings.asset,runtime.settings.forecastMode,runtime.settings.engine,runtime.settings.orderDurationMs,
    pcWindow?.phase,pcWindow?.windowStartedAt,pcWindow?.windowEndsAt,
    mobileEntry?.entryTriggeredAt,mobileEntry?.phase
  ].join('|');
  const sourceEvent=sourceEventKey!==lastLiveSourceEventKey;
  if(Date.now()-liveBridge.lastSentAt<(sourceEvent?0:urgent?500:1100))return;
  livePublishBusy=true;
  try{
    const chosen=chooseLive();if(!chosen?.m)return;
    // Fast path: the remote phone needs the already-computed analyst state,
    // not a second full balance/broker/history/status sweep every second.
    // The authenticated periodic status API still carries full details.
    const snapshot={
      agentVersion:VERSION,state:runtime.stateName,bot:packExecutor(remoteExecutorState()),
      killSwitch:runtime.killSwitch,masterFrozen:runtime.masterFrozen,
      settings:runtime.settings,lastEvalMs:runtime.lastEvalMs,
      lastResult:runtime.lastResult
    };
    if(liveBridge.publish(analystSnapshot(snapshot,chosen.m),{urgent,sourceEvent})){
      lastLiveSentDecisionKey=decisionKey;
      lastLiveSourceEventKey=sourceEventKey;
    }
  }catch{}finally{livePublishBusy=false}
}
const livePublishTimer=setInterval(()=>{void publishLiveFrame()},220);
livePublishTimer.unref?.();
let localCockpitLeaseUntil=0;
const localCockpitLeaseValid=()=>Date.now()<localCockpitLeaseUntil&&!!activeProvider&&brokers[activeProvider]?.connected===true;
let lastBrokerMaintainAt=0,lastOverlayAt=0,lastOverlayTimingKey='',lastOverlayProbeKey='',lastPersistAt=0,lastMarketSyncAt=0;
const realtimeQuotes=new LatestQuoteScheduler({isBusy:()=>busy,isRunning:()=>runtime.stateName==='running',evaluate:async()=>{
  syncRuntimeMarket();lastMarketSyncAt=Date.now();runtime.requestImmediateEvaluation?.();await loop();
}});
driver.setMarketUpdateHandler?.((provider,event={})=>{
  if(provider!==activeProvider)return;
  if(event.assetChanged===true){syncRuntimeMarket();runtime.requestImmediateEvaluation?.();}
  if(runtime.stateName==='running'){
    // Send the observed quote immediately, BEFORE the potentially expensive
    // forecast evaluation. The existing receipt still keeps its real timestamp.
    // This does not create a signal, read the broker twice, or write to the DB.
    void publishLiveFrame();
    realtimeQuotes.request();
  }
});
async function ensureLocalCockpitBroker(provider){
  assertLicensedAccess();
  const adapter=brokers[provider];if(!adapter)throw new Error('Corretora não suportada.');
  activeProvider=provider;
  let info=await driver.sessionInfo?.(provider).catch(()=>null);
  if(!info?.open){
    info=await driver.call(provider,'resume-visible',{body:{startup:false}}).catch(()=>null);
    if(!info?.open)throw new Error('Não foi possível abrir a corretora.');
  }
  if(!adapter.connected){
    await driver.call(provider,'connect',{body:{sessionRef:adapter.sessionRef||null,accountMode:'auto'}});
    adapter.connected=true;adapter._step?.('session',true,'sessão local conectada pelo card');
  }
  await driver.maintain?.(provider).catch(()=>{});
  adapter.refreshFromLive?.();
  const live=syncRuntimeMarket();
  if(!live)throw new Error('Aguardando leitura do ativo atual.');
  return live
}
driver.setOverlayActionHandler?.(async(provider,payload={})=>{
  const action=String(payload.action||'');
  if(action.startsWith('executor-')){if(action!=='executor-stop'&&provider!==activeProvider)throw Error('Selecione a corretora ativa.');return executorAction(action,payload);}
  if(!['pause','stop'].includes(action))assertLicensedAccess();
  if(action==='start'){
    localCockpitLeaseUntil=Date.now()+12*60*60*1000;
    await ensureLocalCockpitBroker(provider);
    const live=syncRuntimeMarket(),mode=String(live?.m?.mode||live?.mode||driver.liveStatus?.(provider)?.mode||'').toLowerCase();
    runtime.patchSettings({demoAutopilot:false},'overlay');
    await runtime.start('overlay');
    runtime.requestImmediateEvaluation?.();
    await saveState();
    return{ok:true,message:'Análise iniciada · operação manual somente'}
  }
  if(action==='refresh'){localCockpitLeaseUntil=Date.now()+12*60*60*1000;activeProvider=provider;const adapter=brokers[provider];await driver.maintain?.(provider).catch(()=>{});await driver.requestBaseData?.(provider).catch(()=>{});await driver.requestMarketData?.(provider,{force:true}).catch(()=>{});adapter?.refreshFromLive?.();syncRuntimeMarket();runtime.requestImmediateEvaluation?.();await runtime.tick(Date.now()).catch(()=>{});return{ok:true,message:'Leitura atualizada'}}
  if(action==='pause'){executor.stop('Analista pausado',{reset:true});localCockpitLeaseUntil=Date.now()+12*60*60*1000;activeProvider=provider;await runtime.pause('overlay');await saveState();return{ok:true,message:'Bot pausado'}}
  if(action==='stop'){executor.stop('Analista parado',{reset:true});localCockpitLeaseUntil=0;activeProvider=provider;runtime.patchSettings({demoAutopilot:false},'overlay');await runtime.stop('overlay','manual');await saveState();return{ok:true,message:'Analista parado · execução automática desativada'}}
  if(action==='setting'){
    localCockpitLeaseUntil=Date.now()+12*60*60*1000;
    const key=String(payload.key||''),value=payload.value;
    if(key==='uiLanguage'){runtime.patchSettings({uiLanguage:String(value)},'overlay');await saveState();return{ok:true};}
    if(key==='forecastMode'){runtime.patchSettings({forecastMode:String(value)},'overlay');runtime.requestImmediateEvaluation?.();await saveState();return{ok:true};}
    if(key==='engine'){
      const allowed=['automatic','smart_confluence','price_action','trendline_breakout','support_resistance','fibonacci_retest','trend','mean_reversion','breakout'];
      if(!allowed.includes(String(value)))throw new Error('invalid_engine');
      runtime.patchSettings({engine:String(value),strategy2:'none',strategy3:'none'},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else if(key==='strategy'||key==='strategy2'||key==='strategy3'){
      const allowed=['smart_confluence','price_action','trendline_breakout','support_resistance','fibonacci_retest','trend','mean_reversion','breakout'];
      const optional=key!=='strategy';
      if(!(optional&&String(value)==='none')&&!allowed.includes(String(value)))throw new Error('invalid_strategy');
      runtime.patchSettings({[key]:String(value)},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else if(key==='duration'){
      const n=Number(value);if(![5000,10000,15000,30000].includes(n))throw new Error('invalid_short_operation_duration');
      runtime.patchSettings({orderDurationMs:n,forecastHorizonSeconds:Math.round(n/1000)},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else if(key==='forecastHorizon'){
      const n=Math.round(Number(value));if(![30,60,120,300,600,900,3600].includes(n))throw new Error('invalid_forecast_horizon');
      runtime.patchSettings({forecastHorizonSeconds:n},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else if(key==='minConfidence'){
      const n=Math.round(Number(value));if(!Number.isFinite(n)||n<55||n>95)throw new Error('invalid_min_confidence');
      runtime.patchSettings({risk:{minConfidence:n}},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else if(key==='futureDisplayThreshold'){
      const n=Math.round(Number(value));if(!Number.isFinite(n)||n<50||n>95)throw new Error('invalid_future_threshold');
      runtime.patchSettings({futureDisplayThreshold:n},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else if(key==='readingPause'){
      const allowed=['market_confluence','market_entry','market_reversal','strategy_1','strategy_2','strategy_3'];
      const reading=String(payload.reading||'');if(!allowed.includes(reading))throw new Error('invalid_reading_pause');
      const paused=value===true||String(value)==='true';
      runtime.patchSettings({pausedReadings:{[reading]:paused}},'overlay');
      runtime.requestImmediateEvaluation?.();
    }else throw new Error('invalid_overlay_setting');
    await saveState();return{ok:true,message:'Configuração aplicada'}
  }
  throw new Error('invalid_overlay_action')
});
// Keep a previously verified lease through a brief transport outage.
// A confirmed denial still pauses immediately; this never renews browser presence.
const ACCESS_LEASE_GRACE_MS=180000;
function accessLeaseValid(){return remoteRelay.info.paired===true&&remoteRelay.info.accessActive===true&&remoteRelay.info.lastContactAt!=null&&(Date.now()-Number(remoteRelay.info.lastContactAt))<=ACCESS_LEASE_GRACE_MS}
function assertLicensedAccess(){
  if(!remoteRelay.info.paired)throw new Error('agent_not_paired');
  if(remoteRelay.info.accessActive!==true)throw new Error(remoteRelay.info.accessReason||'agent_access_inactive');
  if(!accessLeaseValid())throw new Error('agent_access_unverified');
  return true
}
// License/signed-in presence is independent of the manual analysis switch.
let suspendedForAccess=false;
async function enforceAccessLease(){
  if(accessLeaseValid()){
    if(suspendedForAccess&&runtime.stateName==='paused'){
      try{
        // Resume only the running session we paused for a lost lease.
        // A manual stop/kill while offline must never start by itself.
        await runtime.start('system-access-restored');
        suspendedForAccess=false;
        runtime.vnextWindowState=null;
        runtime.vnextHorizonMatrix=null;
        runtime.vnextFutureEntryAnchor=null;
        runtime.vnextWindowCheckedQuoteAt=0;
        runtime.requestImmediateEvaluation?.();
      }catch(e){
        remoteRelay.info.lastError='access_resume_waiting: '+String(e?.message||e);
        return false;
      }
    }else if(suspendedForAccess&&runtime.stateName!=='paused'){
      suspendedForAccess=false;
    }
    return true;
  }
  if(runtime.stateName==='running'){
    suspendedForAccess=true;
    await runtime.pause('system-access-lost');
    runtime.vnextWindowState=null;
    runtime.vnextHorizonMatrix=null;
    runtime.vnextFutureEntryAnchor=null;
    runtime.vnextWindowCheckedQuoteAt=0;
    runtime.lastResult={action:'WAIT',reasons:['Sessão inativa: aguardando login autorizado']};
  }
  // Closing the last site tab pauses analyses; a valid login and paid
  // entitlement resume only a session which was running before the loss.
  return false;
}
async function loadState(){try{runtime.restore(JSON.parse(await readFile(STATE_FILE,'utf8')))}catch(e){if(e?.code!=='ENOENT')console.error('state_load_error',e)}}
async function saveState(){try{await mkdir(dirname(STATE_FILE),{recursive:true});const tmp=`${STATE_FILE}.tmp`;await writeFile(tmp,JSON.stringify(runtime.snapshotPersistent(),null,2));await rename(tmp,STATE_FILE)}catch(e){console.error('state_save_error',e)}}
await loadState();
try{
 const saved=JSON.parse(await readFile(executorSettingsFile,'utf8'));
 // Old installations could retain levels 4-10. Migrate to the new safe cap
 // instead of rejecting the entire saved bot configuration on startup.
 if(Number.isInteger(saved?.martingaleLevels)&&saved.martingaleLevels>3)
  saved.martingaleLevels=3;
 executor.configure(saved);
}catch{}
try{uiExecutor.restoreBindings(JSON.parse(await readFile(executorTargetsFile,'utf8')))}catch{}
// The bot ALWAYS starts disarmed, including after an Agent update/restart.
// Product now presents Continuous only. Migrate a saved Selective choice
// once, without modifying any Continuous forecast rule or old signal history.
if(runtime.settings.forecastMode==='selective'){
  runtime.patchSettings({forecastMode:'continuous'},'product-mode-migration');
  await saveState();
}
// The Agent starts without opening ANY broker. A stored IQ Option profile
// is not consent to open that broker on every installation, Agent restart or
// Windows login. The user chooses IQ Option or Exnova from the Corretora page;
// /brokers/{provider}/login is the explicit manual action. An ALREADY
// open broker is still recognized by autoConnectVisibleBrokers below.
const overlayCache=new Map();
let overlayAssetKey='';
function overlayAnalysis(view,asset,now=Date.now()){
  const key=String(asset||'—').trim().toUpperCase(),switched=!!overlayAssetKey&&overlayAssetKey!==key;
  overlayAssetKey=key;
  const resultAsset=String(view.lastResult?.asset||view.lastResult?.analysis?.asset||'').trim().toUpperCase();
  const sameAsset=!!key&&!!resultAsset&&key===resultAsset;
  const current=sameAsset?(view.lastResult?.analysis||null):null;
  const cycle=current?.vnext?.opportunityWindow;
  const cycleStartsAt=Number(cycle?.windowStartedAt||0);
  const cycleEndsAt=Number(cycle?.windowEndsAt||0);
  const currentQuoteAt=Number(view.liveBroker?.lastQuoteAt||view.feed?.quoteTs||0);
  // A finished window is never the "current" card for its successor.
  // Clear the old direction while waiting for a real next-cycle quote.
  if(view.settings?.engine){
    overlayCache.delete(key);
    // The legacy expiry boundary stays authoritative. In NOW scanning
    // there is no opened entry window and a broker tick may be a few
    // milliseconds older than the evaluation timestamp. Never hide the
    // entire analysis merely because of that ordinary quote transport gap.
    if(!current||switched||(cycleEndsAt>0&&now>=cycleEndsAt)||
       (cycleStartsAt>0&&currentQuoteAt<cycleStartsAt&&
         shouldDiscardVnextFrame({analysis:current,quoteAt:currentQuoteAt,now,switched})))
      return {analysis:{asset:key,side:'WAIT',reasons:['Aguardando nova janela e cotação']},transient:false};
    return{analysis:current,transient:false};
  }
  const complete=current&&current.metrics&&current.finalConfluence&&Number.isFinite(Number(current.confidence));
  if(complete){overlayCache.set(key,{analysis:current,at:now});return{analysis:current,transient:false}}
  if(!switched){const cached=overlayCache.get(key);if(cached&&now-Number(cached.at||0)<=2200)return{analysis:cached.analysis,transient:true}}
  return{analysis:current||{},transient:false}
}
// Only local timings; never poll, touch the broker account or write DB rows.
const brokerMaintenancePending=new Set();
const brokerMaintenancePerformance={};
const evaluationPerformance={lastMs:0,averageMs:0,slowCount:0,lastQuoteToDecisionAgeMs:null,lastEntryTimingDelayMs:null,lastEntryEventAt:0};
function scheduleBrokerMaintenance(provider){
 // A broker DOM scan/network maintenance request must never compete with
 // actual CALL/PUT dispatch. It will retry next 2.5-second maintenance cycle
 // without changing the model, price capture, expiry or balance handling.
 if(executor.executing||uiExecutor.attempt)return;
 if(brokerMaintenancePending.has(provider))return;
 brokerMaintenancePending.add(provider);
 const started=Date.now();
 Promise.resolve().then(()=>driver.maintain?.(provider))
  .then(()=>brokers[provider]?.refreshFromLive?.())
  .catch(()=>{})
  .finally(()=>{
    const elapsed=Date.now()-started,old=brokerMaintenancePerformance[provider]||{};
    brokerMaintenancePerformance[provider]={lastMs:elapsed,
      averageMs:Math.round(old.averageMs?old.averageMs*.8+elapsed*.2:elapsed),
      slowCount:(old.slowCount||0)+(elapsed>1000?1:0),samples:(old.samples||0)+1};
    brokerMaintenancePending.delete(provider);
  });
}
let shuttingDown=false;
let busy=false;async function loop(){if(shuttingDown||busy)return;busy=true;try{
  executor.observeBalance(activeProvider?driver.accountBalanceSnapshot?.(activeProvider)||null:null);
  executor.watch();
  const licensed=await enforceAccessLease();
  if(!licensed){if(Date.now()-lastPersistAt>=5000){lastPersistAt=Date.now();await saveState()}return}
  if(activeProvider){
    const activePeek=driver.peek?.(activeProvider);
    if(activePeek?.updatedAt&&activePeek.open===false){
      if(brokers[activeProvider])brokers[activeProvider].connected=false;
      activeProvider=null;lastBrokerMaintainAt=0;lastMarketSyncAt=0;lastOverlayAt=0
    }
  }
  if(activeProvider&&brokers[activeProvider]?.connected&&Date.now()-lastBrokerMaintainAt>=2500){lastBrokerMaintainAt=Date.now();scheduleBrokerMaintenance(activeProvider)}
  const loopNow=Date.now();if(!lastMarketSyncAt||loopNow-lastMarketSyncAt>=700){lastMarketSyncAt=loopNow;syncRuntimeMarket()}
  // Live broker quote events and the dedicated 220ms signed-feed timer
  // already publish the latest pre-analysis source values. Do not duplicate
  // the expensive mobile snapshot serialization in the critical quote->click
  // path just before runtime.tick(). The post-decision publish below stays
  // immediate so newly confirmed CALL/PUT still reaches mobile promptly.
  const tickStarted=Date.now();
  await runtime.tick(loopNow,{skipStatus:true});
  executor.pulse();
  // Deliver a confirmed decision immediately, BEFORE timing diagnostics,
  // broker overlay rendering, journals or any other optional work.
  void publishLiveFrame();
  const tickElapsed=Date.now()-tickStarted;
  evaluationPerformance.lastMs=tickElapsed;
  evaluationPerformance.averageMs=Math.round(evaluationPerformance.averageMs?
    evaluationPerformance.averageMs*.8+tickElapsed*.2:tickElapsed);
  if(tickElapsed>500)evaluationPerformance.slowCount++;
  const liveQuoteAt=Number(runtime.externalMarket?.lastQuoteAt||0);
  evaluationPerformance.lastQuoteToDecisionAgeMs=liveQuoteAt>0?
    Math.max(0,Date.now()-liveQuoteAt):null;
  const fired=runtime.lastResult?.analysis?.vnext?.futureEntryAnchor;
  if(fired?.phase==='fired'&&Number(fired.entryTriggeredAt)>evaluationPerformance.lastEntryEventAt){
    evaluationPerformance.lastEntryEventAt=Number(fired.entryTriggeredAt);
    evaluationPerformance.lastEntryTimingDelayMs=Number.isFinite(Number(fired.plannedEntryAt))?
      Number(fired.entryTriggeredAt)-Number(fired.plannedEntryAt):null;
  }
  if(runtime.lastEvalMs!==journalAnalysisAt){journalAnalysisAt=runtime.lastEvalMs;if(activeProvider)driver.setPredictionPeriod?.(activeProvider,runtime.lastResult?.analysis?.predictionInputQuality?.periodSeconds);if(recordMarketJournal)marketJournal.analysis(runtime.lastResult?.analysis,runtime.settings.asset,journalAnalysisAt);for(const event of runtime.forecastResearch.drain())if(recordMarketJournal)marketJournal.enqueue(event)}
  if(activeProvider){
    // A full status() rebuild includes research summaries, broker metadata and
    // trade aggregates. Keep it OUT of the 400ms quote-analysis loop unless an
    // overlay actually needs painting or its operational state has changed.
    const pendingOp=runtime.lastResult?.analysis?.operationalSignal||{};
    const pendingScenario=pendingOp.scenario||{};
    const cycleDeadline=Number(runtime.lastResult?.analysis?.vnext?.opportunityWindow?.windowEndsAt||0);
    const expiredOpportunityFrame=cycleDeadline>0&&Date.now()>=cycleDeadline;
    const overlayFastKey=[
      activeProvider,runtime.settings.asset,runtime.settings.engine,runtime.settings.forecastMode,runtime.settings.orderDurationMs,
      pendingScenario.side,pendingScenario.status,pendingScenario.closed,expiredOpportunityFrame,
      pendingOp.createdAt,pendingOp.side,pendingOp.state,pendingOp.ready,
      pendingOp.actionable,pendingOp.activeUntil,
      // A new future entry is a FIRST-CLASS decision change, not a
      // once-per-second cosmetic refresh. Deliver the new PC deadline
      // on the same evaluated frame used by the mobile signed broadcast.
      runtime.lastResult?.analysis?.vnext?.futureEntryAnchor?.issuedAt,
      runtime.lastResult?.analysis?.vnext?.futureEntryAnchor?.entryAt,
      runtime.lastResult?.analysis?.vnext?.futureEntryAnchor?.side,
      runtime.lastResult?.analysis?.vnext?.futureEntryAnchor?.phase,
      runtime.lastResult?.analysis?.vnext?.opportunityWindow?.phase,
       runtime.lastResult?.analysis?.vnext?.opportunityWindow?.windowStartedAt,
       runtime.lastResult?.analysis?.vnext?.opportunityWindow?.windowEndsAt,
       runtime.lastResult?.analysis?.vnext?.futureEntryAnchor?.entryTriggeredAt
    ].join('|');
    if(overlayFastKey!==lastOverlayProbeKey||Date.now()-lastOverlayAt>=1000){
      lastOverlayProbeKey=overlayFastKey;
      const view=lightweightOverlayView(runtime);
    const brokerSwitching=String(view.liveBroker?.marketStatus||'').toLowerCase()==='switching'&&!view.liveBroker?.uiSymbol&&!view.liveBroker?.symbol;
    const currentAsset=brokerSwitching?'SINCRONIZANDO':(view.liveBroker?.uiSymbol||view.liveBroker?.symbol||view.settings?.asset||'—');
    const held=overlayAnalysis(view,currentAsset),a=held.analysis||{},m=a.metrics||{};
    const next=view.nextEvalMs?new Date(view.nextEvalMs).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',second:'2-digit'}):'—';
    // Match the strategy's quote-freshness gate. A new historical candle must
    // never make an old live quote appear current to the trader.
    const liveTs=Number(view.liveBroker?.lastQuoteAt||view.feed?.quoteTs||view.liveBroker?.lastCandleAt||0);
    const forecastSeconds=view.settings?.engine?Math.max(5,Number(view.settings?.orderDurationMs||60000)/1000):Math.max(30,Number(view.settings?.forecastHorizonSeconds||Math.round(Number(view.settings?.orderDurationMs||60000)/1000)));
    const configuredFreshnessMs=Math.max(500,Number(view.settings?.risk?.maxFeedLatencyMs||2500));
    const effectiveQuoteFreshnessMs=forecastSeconds<=30?Math.min(configuredFreshnessMs,1500):forecastSeconds<=60?Math.min(configuredFreshnessMs,2000):configuredFreshnessMs;
    const quoteStale=!(liveTs>0)||Date.now()-liveTs>effectiveQuoteFreshnessMs;
    const op=a.operationalSignal||{},scenario=op.scenario||{},
      overlayTimingKey=[currentAsset,scenario.side,scenario.status,scenario.closed,expiredOpportunityFrame,
        op.createdAt,op.side,op.state,op.ready,op.actionable,op.activeUntil,
        a.vnext?.futureEntryAnchor?.issuedAt,
        a.vnext?.futureEntryAnchor?.entryAt,
        a.vnext?.futureEntryAnchor?.side,
        a.vnext?.futureEntryAnchor?.phase,
        a.vnext?.opportunityWindow?.phase,
        a.vnext?.opportunityWindow?.windowStartedAt,
        a.vnext?.opportunityWindow?.windowEndsAt,
        a.vnext?.futureEntryAnchor?.entryTriggeredAt].join('|');
    const urgentOverlay=overlayTimingKey!==lastOverlayTimingKey;
    if(overlayTimingKey!==lastOverlayTimingKey||Date.now()-lastOverlayAt>=1000){
      lastOverlayTimingKey=overlayTimingKey;
      lastOverlayAt=Date.now();
    overlayUpdates.publish(activeProvider,{
      asset:currentAsset,
      validatedAsset:view.liveBroker?.validatedSymbol||view.liveBroker?.symbol||currentAsset,
      assetValidated:view.liveBroker?.assetValidated===true,
      // Exact live broker quote for the PC overlay; previously omitted, so
      // PREÇO AGORA rendered as a dash despite a fresh broker feed.
      price:view.liveBroker?.quote??view.feed?.price??null,
      quoteAt:liveTs>0?liveTs:null,
      screenCandidateSymbol:view.liveBroker?.screenCandidateSymbol||null,
      marketStatus:view.liveBroker?.marketStatus||null,
      marketReason:view.liveBroker?.marketReason||null,
      engine:view.settings?.engine||null,forecastMode:view.settings?.forecastMode||'continuous',
      uiLanguage:view.settings?.uiLanguage||'pt',
       vnext:a.vnext||null,
       strategy:view.settings?.strategy||'smart_confluence',
      strategy2:view.settings?.strategy2||'none',
      strategy3:view.settings?.strategy3||'none',
      strategyCards:a.strategyCards||[],
      strategyGuidance:a.strategyGuidance||null,
      strategyConfluence:a.strategyConfluence||null,
      generalConsensus:a.generalConsensus||null,
      operationalSignal:a.operationalSignal||null,
      brokerExpirationDurationMs:view.liveBroker?.expirationDurationMs??null,
      brokerExpirationRaw:view.liveBroker?.expirationRaw??null,
      brokerExpirationKind:view.liveBroker?.expirationKind??null,
      brokerExpirationConfidence:view.liveBroker?.expirationConfidence??0,
      side:a.side||'WAIT',
      confidence:a.confidence||0,
      forecast30:a.forecast30||null,
      finalConfluence:a.finalConfluence||null,
      entryPlanner:a.entryPlanner||null,
      quality:a.quality||view.signalValidation||null,
      minConfidence:view.settings?.risk?.minConfidence||74,
      futureDisplayThreshold:view.settings?.futureDisplayThreshold||70,
      pausedReadings:view.settings?.pausedReadings||{},
      reasons:a.reasons||view.lastResult?.reasons||[],
      metrics:m,
      plan:view.lastResult?.plan||{},
      nextEval:next,
      realtime:true,
      analysisTransient:held.transient,
      // The NOW engine requires authenticated live quotes, NOT historical
      // candle validation. The visual state must obey the same source gate.
      analysisStale:!view.liveBroker||quoteStale||(a.vnext?.mode==='now'
        ?(view.liveBroker.quoteFeedValidated!=null?
          view.liveBroker.quoteFeedValidated!==true:
          !(view.liveBroker.analysisFeedValidated===true||view.liveBroker.feedValidated===true))
        :(view.liveBroker.analysisFeedValidated===false||
          (view.liveBroker.analysisFeedValidated==null&&view.liveBroker.feedValidated===false))),
      liveAgeMs:liveTs>0?Math.max(0,Date.now()-liveTs):null,
      analysisAgeMs:view.lastEvalMs?Math.max(0,Date.now()-Number(view.lastEvalMs)):null,
      durationMs:view.settings?.orderDurationMs||60000,
      forecastHorizonSeconds:view.settings?.forecastHorizonSeconds||Math.round(Number(view.settings?.orderDurationMs||60000)/1000),
      intervalMs:view.settings?.schedule?.intervalMs||1000,
      brokerMode:view.liveBroker?.mode||view.mode,
      mode:view.mode,
      state:view.state,
      demoAutopilot:view.autopilot?.enabled===true,
      executionReady:view.autopilot?.eligible===true,
      agentVersion:VERSION,autoExecutor:{...executor.status(),provider:activeProvider,controlsMapped:!!uiExecutor.canvasBindings[activeProvider]}
    },{urgent:urgentOverlay});
    }
    }
  }
  if(Date.now()-lastPersistAt>=5000){lastPersistAt=Date.now();await saveState()}
}catch(e){console.error('worker_loop_error',e)}finally{busy=false}}setInterval(loop,200).unref();
function brokerStatuses(){return Object.fromEntries(Object.entries(brokers).map(([k,v])=>[k,{...v.status(),marketData:driver.liveStatus?.(k)||null}]))}
async function status(){if(activeProvider&&brokers[activeProvider]?.connected)brokers[activeProvider].refreshFromLive?.();const chosen=syncRuntimeMarket();const base=await runtime.status();const provider=chosen?.k||null,live=chosen?.m||null;
  return{...base,autoExecutor:remoteExecutorState(),marketJournal:{...marketJournal.status(),enabled:recordMarketJournal},agentVersion:VERSION,liveTopic,liveSignatureKey,remoteRelay:{...remoteRelay.info},runtimeKind:'persistent-worker',browserDriver:{configured:driver.available,type:driver instanceof LocalPlaywrightDriver?'system-browser-playwright':'remote-http',overlayPerformance:overlayUpdates.metrics()},
    timingDiagnostics:{evaluation:{...evaluationPerformance},brokerMaintenance:{...brokerMaintenancePerformance}},
    sessionVault:{configured:true},brokers:brokerStatuses(),loginStates:{iq_option:driver.peek?.('iq_option')||loginStates.iq_option,exnova:driver.peek?.('exnova')||loginStates.exnova},activeProvider:provider,liveBroker:provider?{provider,...live}:null,...(live?.balance!=null?{balance:live.balance,balanceSource:'broker'}:{}),...(live?.quote!=null?{feed:{label:`${provider==='exnova'?'EXNOVA':'IQ OPTION'} LIVE`,price:live.quote,quoteTs:live.lastQuoteAt||live.lastCandleAt||0}}:{})}}
const DEFAULT_ALLOWED_ORIGINS=['https://sentinel-trading-lab.vercel.app','https://sentinel-trading-lab-iguassu-shop.vercel.app','https://trading.devinx.com.br','https://sentinel.devinx.com.br'];
const EXTRA=(process.env.SENTINEL_ALLOWED_ORIGINS||'').split(',').map(v=>v.trim()).filter(Boolean);const ALLOWED_ORIGINS=new Set([...DEFAULT_ALLOWED_ORIGINS,...EXTRA]);
function allowedOrigin(origin=''){
  if(origin===''||origin==='http://localhost:3000'||origin==='http://127.0.0.1:3000')return true;
  if(ALLOWED_ORIGINS.has(origin))return true;
  return false;
}
function cors(req){const origin=String(req.headers.origin||'');const h={'access-control-allow-methods':'GET,POST,PATCH,DELETE,OPTIONS','access-control-allow-headers':'content-type,authorization','access-control-max-age':'600','cache-control':'no-store','vary':'Origin'};if(allowedOrigin(origin))h['access-control-allow-origin']=origin||'*';if(req.headers['access-control-request-private-network']==='true')h['access-control-allow-private-network']='true';return h}
function json(req,res,statusCode,data){res.writeHead(statusCode,{'content-type':'application/json; charset=utf-8',...cors(req)});res.end(JSON.stringify(data))}
async function body(req){let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>65536)throw new Error('body_too_large')}return raw?JSON.parse(raw):{}}
function authorized(req){if(!TOKEN)return true;return(req.headers.authorization||'')===`Bearer ${TOKEN}`}
function providerFromPath(path){const m=path.match(/^\/brokers\/(iq_option|exnova)(?:\/(.+))?$/);return m?{name:m[1],action:m[2]||''}:null}
function requiresAccess(path){
  if(path==='/status'||path==='/control/stop'||path==='/control/kill')return false;
  return path==='/control/start'||path==='/mode'||path==='/settings'||path.startsWith('/brokers/');
}
function ensureAccess(path,{local=false}={}){
  if(!requiresAccess(path))return;
  assertLicensedAccess();
}
async function act(path,method,payload,ctx={}){ensureAccess(path,ctx);if(path.startsWith('/executor/')&&method==='POST'){if(path==='/executor/start'&&(executor.enabled||executor.arming))throw Error('Bot já ligado ou em ativação.');await dispatchExecutor(path,payload,executorAction,executionContext);return status();}if(path==='/diagnostics/market'&&method==='POST')return marketDiagnostic(runtime,runtime.externalMarket||{});if(path==='/status'&&method==='GET')return status();if(path==='/research'&&method==='GET')return{summary:runtime.forecastResearch.summary(),entries:runtime.entryResearch.summary(),entryOutcomes:runtime.entryResearch.outcomes.slice(-100),journal:marketJournal.status(),outcomes:runtime.forecastResearch.outcomes.slice(-100)};if(path==='/control/start'&&method==='POST'){if(activeProvider&&brokers[activeProvider]?.connected){await driver.maintain?.(activeProvider).catch(()=>{});brokers[activeProvider].refreshFromLive?.()}syncRuntimeMarket();return runtime.start(payload.actor||'user')};if(path==='/control/pause'&&method==='POST'){suspendedForAccess=false;return runtime.pause(payload.actor||'user')}if(path==='/control/stop'&&method==='POST'){suspendedForAccess=false;return runtime.stop(payload.actor||'user',payload.reason||'manual')}if(path==='/control/kill'&&method==='POST'){suspendedForAccess=false;return runtime.kill(payload.actor||'user')}if(path==='/control/reset-kill'&&method==='POST')return runtime.resetKill(payload.actor||'master');if(path==='/control/freeze'&&method==='POST')return runtime.freeze(payload.actor||'master');if(path==='/control/unfreeze'&&method==='POST')return runtime.unfreeze(payload.actor||'master');if(path==='/control/clear-error'&&method==='POST')return runtime.clearExecutionError(payload.actor||'master');if(path==='/mode'&&method==='POST'){
    if(payload?.brokerSwitch===true){
      const provider=String(payload.provider||activeProvider||'');
      if(!['iq_option','exnova'].includes(provider)||!brokers[provider]?.connected)
        throw new Error('broker_not_connected');
      if(typeof driver.switchBrokerAccount!=='function')throw new Error('broker_remote_account_switch_unsupported');
      await withTimeout(driver.switchBrokerAccount(provider,payload.mode),11000,'broker_account_switch_timeout');
      brokers[provider].refreshFromLive?.();activeProvider=provider;syncRuntimeMarket();
      return status();
    }
    return runtime.setMode(payload.mode,payload.actor||'user')
  }if(path==='/settings'&&method==='PATCH')return runtime.patchSettings(payload,payload.actor||'user');if(path==='/tick'&&method==='POST'){await runtime.tick(Number(payload.now||Date.now()));return status()}if(path==='/brokers'&&method==='GET')return status();
  const p=providerFromPath(path);if(p){const adapter=brokers[p.name];if(p.action==='status'&&method==='GET')return{broker:{...adapter.status(),marketData:driver.liveStatus?.(p.name)||null},login:driver.peek?.(p.name)||loginStates[p.name]};if(p.action==='login'&&method==='POST'){
    loginStates[p.name]={provider:p.name,open:true,phase:'opening',updatedAt:new Date().toISOString()};
    try{
      const info=await withTimeout(driver.call(p.name,'login',{body:{accountMode:'auto',userInitiated:payload.userInitiated===true}}),28000,'broker_open_timeout');
      loginStates[p.name]=info;
      if(!info?.open)throw new Error(info?.error||'broker_window_not_open');
      return status()
    }catch(e){
      const err=String(e?.message||e);
      loginStates[p.name]={provider:p.name,open:false,phase:'open-error',error:err,updatedAt:new Date().toISOString()};
      throw new Error(err)
    }
  }if(p.action==='session-check'&&method==='POST'){const info=await driver.call(p.name,'session',{method:'GET'});loginStates[p.name]=info;if(!info.sessionPresent)throw new Error('session_not_detected_yet');const sessionRef=`local-profile:${p.name}`;await vault.put(p.name,sessionRef);adapter.attachSessionRef(sessionRef);// Keep the already authenticated VISIBLE traderoom. Spawning a new headless browser here left CALL/PUT/Valor unreachable in the user's PC window.
    await adapter.connect();if(adapter.connected)activeProvider=p.name;syncRuntimeMarket();return status()}if(p.action==='connect'&&method==='POST'){await adapter.connect();activeProvider=p.name;syncRuntimeMarket();return status()}if(p.action==='validate-market'&&method==='POST'){try{await adapter.validateReadOnly()}catch(e){adapter.lastError=String(e?.message||e)}return status()}if(p.action==='disconnect'&&method==='POST'){await adapter.disconnect();loginStates[p.name]=null;if(activeProvider===p.name)activeProvider=null;syncRuntimeMarket();return status()}if(p.action==='session-ref'&&method==='POST'){await vault.put(p.name,payload.sessionRef);adapter.attachSessionRef(vault.get(p.name));return status()}if(p.action==='session-ref'&&method==='DELETE'){await vault.remove(p.name);adapter.attachSessionRef(null);return status()}if(p.action==='validate-demo-order'&&method==='POST')throw new Error('broker_order_execution_retired');
  }
  const err=new Error('not_found');err.status=404;throw err}

let autoBrokerBusy=false;
async function autoConnectVisibleBrokers(){
  if(shuttingDown||autoBrokerBusy||!accessLeaseValid())return;autoBrokerBusy=true;
  try{
    for(const [name,adapter] of Object.entries(brokers)){
      const peek=driver.peek?.(name);
      if(adapter.connected){
        if(!activeProvider&&peek?.open){activeProvider=name;syncRuntimeMarket()}
        continue
      }
      if(!peek?.open)continue;
      let info=null;
      try{
        info=await withTimeout(driver.sessionInfo(name),5000,'broker_session_probe_timeout');
        loginStates[name]=info;
      }catch{continue}
      if(!info?.sessionPresent)continue;
      const sessionRef=`local-profile:${name}`;
      try{
        if(vault.get(name)!==sessionRef)await vault.put(name,sessionRef);
        if(adapter.sessionRef!==sessionRef)adapter.attachSessionRef(sessionRef);
        await withTimeout(adapter.connect(),12000,'broker_auto_connect_timeout');
        if(adapter.connected){
          activeProvider=name;
          syncRuntimeMarket();
        }
      }catch{}
    }
  }finally{autoBrokerBusy=false}
}
setInterval(()=>autoConnectVisibleBrokers().catch(()=>{}),2500).unref();
setTimeout(()=>autoConnectVisibleBrokers().catch(()=>{}),1200).unref();

async function withTimeout(promise,ms,label='operation_timeout'){
  let timer;
  try{
    return await Promise.race([
      Promise.resolve(promise),
      new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(label)),ms)})
    ])
  }finally{clearTimeout(timer)}
}
let remoteBusy=false;
let remoteHeartbeatBusy=false;
async function sendRemoteHeartbeat(){
  if(remoteHeartbeatBusy)return;
  remoteHeartbeatBusy=true;
  try{
    const hb=await remoteRelay.heartbeat(await remoteState());
    if(hb&&hb.accessActive===false)await enforceAccessLease();
  }catch(e){remoteRelay.info.lastError=String(e?.message||e)}
  finally{remoteHeartbeatBusy=false}
}
let lastRemoteHeartbeatAttemptAt=0;
let lastRemoteRegisterAttemptAt=0;
async function remoteState(){
  const x=await status();
  return dashboardTransportState({autoExecutor:x.autoExecutor,agentVersion:VERSION,liveTopic,liveSignatureKey,agentAccess:{paired:remoteRelay.info.paired,active:remoteRelay.info.accessActive,reason:remoteRelay.info.accessReason},remoteRelay:{lastContactAt:remoteRelay.info.lastContactAt,lastError:remoteRelay.info.lastError},browserDriver:x.browserDriver,loginStates:x.loginStates,state:x.state,mode:x.mode,balance:x.balance,balanceSource:x.balanceSource,feed:x.feed,analysisSource:x.analysisSource,executionMode:x.executionMode,lastResult:x.lastResult,lastEvalMs:x.lastEvalMs,nextEvalMs:x.nextEvalMs,recentAnalyses:x.recentAnalyses,research:x.research,entryResearch:x.entryResearch,marketJournal:x.marketJournal,incidents:x.incidents,drawdownPct:x.drawdownPct,consecutiveLosses:x.consecutiveLosses,pending:x.pending,wins:x.wins,losses:x.losses,winRate:x.winRate,settings:x.settings,pnl:x.pnl,trades:x.trades,recentTrades:x.recentTrades,liveBroker:x.liveBroker,activeProvider:x.activeProvider,brokers:x.brokers,startBlockedReason:x.startBlockedReason,killSwitch:x.killSwitch,masterFrozen:x.masterFrozen,scheduler:x.scheduler||x.schedule});
}
async function remoteLoop(){
  if(shuttingDown||remoteBusy)return;remoteBusy=true;
  try{
    const now=Date.now();
    if(!remoteRelay.info.deviceId&&now-lastRemoteRegisterAttemptAt>=30000){
      lastRemoteRegisterAttemptAt=now;
      await remoteRelay.register();
    }
    // Preserve sub-2-second remote command polling while avoiding repeated
    // full dashboard snapshots when stopped or disconnected.
    const heartbeatEveryMs=runtime.stateName==='running'||executor.pending||liveBridge.hasViewer()?5000:20000;
    if(now-lastRemoteHeartbeatAttemptAt>=heartbeatEveryMs){
      lastRemoteHeartbeatAttemptAt=now;
      // Cloud heartbeat must not delay a local quote or mobile command.
      void sendRemoteHeartbeat();
    }
    const polled=await remoteRelay.poll();const cmd=polled?.command;
    if(cmd?.id&&cmd?.type){
      try{
        const method=cmd.type==='settings'?'PATCH':'POST';
        const data=await withTimeout(act('/'+cmd.type,method,cmd.payload||{}),28000,'agent_command_timeout');
        await saveState();
        // ACK the action promptly; publish refreshed state in the next heartbeat.
        await remoteRelay.ack(cmd.id,true,cmd.type==='diagnostics/market'?{ok:true,marketDiagnostic:data}:{ok:true,...(cmd.type.startsWith('executor/')?{autoExecutor:data?.autoExecutor}:{}),state:data?.state||null,mode:data?.mode||null,strategy:data?.settings?.strategy||null,activeProvider:data?.activeProvider||null,loginStates:data?.loginStates||null})
        lastRemoteHeartbeatAttemptAt=0;
      }catch(e){
        await remoteRelay.ack(cmd.id,false,{error:String(e?.message||e).slice(0,180)}).catch(()=>{})
      }
    }
  }catch(e){
    remoteRelay.info.lastError=String(e?.message||e);
    const last=Number(remoteRelay.info.lastContactAt||0);
    if(last>0&&Date.now()-last>ACCESS_LEASE_GRACE_MS){
      remoteRelay.info.accessActive=false;
      remoteRelay.info.accessReason='license_check_unavailable';
      await enforceAccessLease().catch(()=>{});
    }
  }finally{remoteBusy=false}
}
setInterval(remoteLoop,2500).unref();setTimeout(remoteLoop,350).unref();

const server=http.createServer(async(req,res)=>{try{if(req.method==='OPTIONS'){res.writeHead(204,cors(req));return res.end()}const origin=String(req.headers.origin||'');if(origin&&!allowedOrigin(origin))return json(req,res,403,{ok:false,error:'origin_not_allowed'});const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);if(url.pathname==='/health')return json(req,res,200,{ok:true,service:'sentinel-worker',version:VERSION,build:BUILD,pid:process.pid,runtimeKind:'persistent-worker',driverConfigured:driver.available,vaultConfigured:true,remoteRelay:{...remoteRelay.info},ts:new Date().toISOString()});if(url.pathname==='/remote-info')return json(req,res,200,{ok:true,...remoteRelay.info,version:VERSION});if(!authorized(req))return json(req,res,401,{ok:false,error:'unauthorized'});const payload=['POST','PATCH','PUT','DELETE'].includes(req.method||'')?await body(req):{};const addr=String(req.socket?.remoteAddress||'');const local=addr==='127.0.0.1'||addr==='::1'||addr==='::ffff:127.0.0.1';const data=await act(url.pathname,req.method||'GET',payload,{local});if(req.method!=='GET')await saveState();return json(req,res,200,{ok:true,data})}catch(e){return json(req,res,Number(e?.status||400),{ok:false,error:String(e?.message||e)})}});
server.listen(PORT,HOST,()=>console.log(`Sentinel worker v${VERSION} listening on http://${HOST}:${PORT}`));
let shutdownPromise=null;
function shutdownWorker(){
  if(shutdownPromise)return shutdownPromise;
  executor.stop('Agente encerrado');
  shuttingDown=true;
  shutdownPromise=(async()=>{
    // Stop all Agent loops before disposing browser contexts opened by it.
    liveBridge.close();clearInterval(livePublishTimer);
    await Promise.allSettled([saveState(),marketJournal.flush(),Promise.resolve().then(()=>driver.shutdown?.())]);
    server.close(()=>process.exit(0));
    setTimeout(()=>process.exit(0),1000).unref();
  })();
  return shutdownPromise;
}
process.once('SIGTERM',()=>{void shutdownWorker()});
process.once('SIGINT',()=>{void shutdownWorker()});

