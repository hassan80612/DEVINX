import {randomUUID} from 'node:crypto';
import {normalizeCanvasBinding,canvasControlBridge} from './canvas-executor-targets.mjs';
const finite=x=>x!==null&&x!==undefined&&x!==''&&Number.isFinite(Number(x));
const clean=x=>String(x||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
const errorBefore=message=>Object.assign(new Error(message),{beforeClick:true});
// Recognize individually identified and grouped close events. A single frame
// can contain more than one Martingale order; each still needs its own ID.
const frameNames=frame=>[frame?.msg?.name,frame?.name,frame?.msg?.body?.name,frame?.body?.name]
  .filter(x=>typeof x==='string').map(x=>x.toLowerCase());
const closingKind=frame=>{
 const names=frameNames(frame);
 if(names.some(n=>n.endsWith('option-closed')))return'option';
 if(names.some(n=>n.endsWith('position-changed')||n.endsWith('positions-changed')))return'position';
 return null;
};
export function isExecutionFrame(frame){
 return frameNames(frame).some(n=>/option|positions?-changed|order-changed|buyv3|^error$/.test(n));
}
export function settlementFromFrame(provider,frame,known){
 const kind=closingKind(frame),root=frame?.msg?.body??frame?.msg??frame?.body;
 if(!kind||!root||typeof root!=='object'||known?.orderId==null)return null;
 const baseAccount=root.user_balance_id??root.balance_id??root.account_id??null;
 const queue=[{value:root,depth:0}],seen=new Set();
 for(let i=0;i<queue.length&&i<100;i++){
  const {value,depth}=queue[i];
  if(!value||typeof value!=='object'||seen.has(value))continue;
  seen.add(value);
  if(Array.isArray(value)){
   if(depth<4)for(const child of value.slice(0,40))queue.push({value:child,depth:depth+1});
   continue;
  }
  const ids=[value.id,value.option_id,value.position_id,value.external_id,value.order_id]
    .filter(x=>x!=null).map(String);
  if(ids.includes(String(known.orderId))){
   const account=value.user_balance_id??value.balance_id??value.account_id??baseAccount;
   if(account!=null&&known.accountId!=null&&String(account)!==String(known.accountId))return null;
   const stake=value.amount??value.invest;
   if(stake!=null&&(!finite(stake)||Math.abs(Number(stake)-Number(known.amount))>0.000001))return null;
   let gross=null;
   // Only known gross-return fields on identified closed option events.
   if(kind==='option'&&finite(value.profit_amount))gross=Number(value.profit_amount);
   if(kind==='position'&&String(value.status||'').toLowerCase()==='closed'&&
      finite(value.close_profit)&&finite(value.invest))gross=Number(value.close_profit);
   if(gross!==null&&gross>=0){
    const opening=value.open_price??value.open_quote,closing=value.close_price??value.close_quote;
    return{provider,accountId:known.accountId??account??null,orderId:known.orderId,
      netPnl:gross-Number(known.amount),source:'broker',
      ...(finite(opening)&&Number(opening)>0?{entryPrice:Number(opening)}:{}),
      ...(finite(closing)&&Number(closing)>0?{exitPrice:Number(closing)}:{})};
   }
  }
  if(depth<4)for(const key of ['body','option','position','options','positions','data','result','items']){
   const v=value[key];if(v&&typeof v==='object')queue.push({value:v,depth:depth+1});
  }
 }
 return null;
}

// Executed inside the broker page only at activation / selected entry.
// Only locates the direction buttons. Stake and duration are set by the user
// on the broker; the bot's corresponding values are for local accounting.
export function inspectTradeControls({marker}){
 const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&!e.closest('[aria-hidden="true"]');};
 const text=e=>[e.getAttribute('aria-label'),e.getAttribute('title'),e.getAttribute('data-test'),e.getAttribute('data-testid'),e.getAttribute('data-direction'),e.className,e.name,e.id,e.value,e.textContent].filter(Boolean).join(' ').trim();
 const buttons=[...document.querySelectorAll('button,[role="button"],input[type="button"],[onclick],[ng-click],[data-direction],.call-btn,.put-btn,.btn-call,.btn-put,.button-call,.button-put')].filter(e=>visible(e)&&!e.closest('#sentinel-trading-overlay-host')&&!/^tel:/i.test(e.getAttribute('href')||''));
 const choose=(direction)=>buttons.filter(e=>{
  const t=text(e).toLowerCase(),words=direction==='CALL'?'call|higher|acima|arriba|subir|up':'put|lower|abaixo|abajo|bajar|down';
  return new RegExp('(?:^|[\\s_-])(?:'+words+')(?:$|[\\s_-])','i').test(t)&&!/(?:payout|layout|setup|input|group|dropdown)/i.test(t)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true';
 });
 // Nested label/wrapper and button represent one action, not two buttons.
 const deepest=items=>items.filter(e=>!items.some(other=>other!==e&&e.contains(other)));
 const call=deepest(choose('CALL')),put=deepest(choose('PUT'));
 if(call.length!==1||put.length!==1){
  const canvas=[...document.querySelectorAll('canvas')].some(visible);
  return{error:canvas?'Painel gráfico sem botões HTML. Use Mapear CALL/PUT nesta corretora.':'CALL: '+call.length+' · PUT: '+put.length+'. Botões não identificados de forma única.'};
 }
 call[0].setAttribute('data-sentinel-execution-call',marker);put[0].setAttribute('data-sentinel-execution-put',marker);
 return{callSelector:'[data-sentinel-execution-call="'+marker+'"]',putSelector:'[data-sentinel-execution-put="'+marker+'"]'};
}

export class BrokerUiExecutor{
 constructor(driver,{onSent=()=>{},onAccepted=()=>{},onRejected=()=>{},onSettlement=()=>{},onUnexpectedOrder=()=>{}}={}){
  this.driver=driver;this.onSent=onSent;this.onAccepted=onAccepted;this.onRejected=onRejected;this.onSettlement=onSettlement;this.onUnexpectedOrder=onUnexpectedOrder;this.attempt=null;this.orders=new Map();this.awaiting=new Map();this.canvasBindings={};this.outboundSeen=new Set();this.clickQueue=Promise.resolve();
 }
 restoreBindings(value){for(const provider of ['iq_option','exnova'])if(value?.[provider])try{this.canvasBindings[provider]=normalizeCanvasBinding(value[provider]);}catch{}return this.canvasBindings;}
 async beginCalibration(provider){
  const page=this.driver.sessions.get(provider)?.page;if(!page||page.isClosed?.())throw errorBefore('Janela da corretora não está conectada.');
  const result=await page.evaluate(canvasControlBridge,{action:'calibrate',label:provider==='iq_option'?'IQ Option':'Exnova'});if(result?.error)throw errorBefore(result.error);return result;
 }
 async saveBinding(provider,value){
  if(!['iq_option','exnova'].includes(provider))throw errorBefore('Corretora inválida.');
  const binding=normalizeCanvasBinding(value),page=this.driver.sessions.get(provider)?.page;
  if(!page||page.isClosed?.())throw errorBefore('Janela da corretora não está conectada.');
  const resolved=await page.evaluate(canvasControlBridge,{action:'resolve',binding,marker:randomUUID()});if(resolved?.error)throw errorBefore(resolved.error);
  this.canvasBindings[provider]=binding;return this.canvasBindings;
 }
 async controls(provider){
  const page=this.driver.sessions.get(provider)?.page;
  if(!page||page.isClosed?.())throw errorBefore('Janela da corretora não está conectada.');
  if(this.canvasBindings[provider]){
   const found=await page.evaluate(canvasControlBridge,{action:'resolve',binding:this.canvasBindings[provider],marker:randomUUID()});
   if(found?.error)throw errorBefore(found.error);return{frame:page,...found};
  }
  let found=null,frame=null,reason=null;
  for(const f of page.frames()){
   let v;try{v=await f.evaluate(inspectTradeControls,{marker:randomUUID()});}catch{continue;}
   if(v?.error)reason=v.error;
   if(v?.callSelector){if(found)throw errorBefore('Mais de um painel de negociação aberto.');found=v;frame=f;}
  }
  if(!found)throw errorBefore(reason||'Botões CALL/PUT não identificados. Abra o painel de negociação.');
  if(found?.error||!found?.callSelector)throw errorBefore(found?.error||'Aguardando painel da nova operação.');
  return{frame,...found};
 }
 checkContext(provider,expected){
  const s=this.driver.state(provider);
  if(clean(s.symbol)!==clean(expected.asset)||Number(s.activeId)!==Number(expected.activeId)||s.screenCandidateSymbol)throw errorBefore('Ativo mudou na corretora.');
 }
 async prepare(provider,expected){this.checkContext(provider,expected);await this.controls(provider);return{ready:true};}
 async execute(provider,order){
  let yes,no,sentYes,sentNo,timer;
  const confirmation=new Promise((resolve,reject)=>{yes=resolve;no=reject;});confirmation.catch(()=>{});
  const sent=new Promise((resolve,reject)=>{sentYes=resolve;sentNo=reject;});sent.catch(()=>{});
  const attempt={provider,order,requestId:null,resolve:yes,reject:error=>{sentNo(error);no(error);},sent:sentYes};
  // Serialize only the physical clicks and their outgoing messages. Do not
  // wait for network acknowledgements between clicks in the same sequence.
  const click=this.clickQueue.catch(()=>{}).then(async()=>{
   this.checkContext(provider,order);const c=await this.controls(provider);
   this.checkContext(provider,order);if(!order.isValid())throw errorBefore('Sinal expirou ou bot foi parado antes da entrada.');
   this.attempt=attempt;
   timer=setTimeout(()=>attempt.reject(Error('Clique sem confirmação da corretora · não será repetido.')),8000);
   const before=()=>{this.checkContext(provider,order);if(!order.isValid())throw errorBefore('Entrada cancelada antes do clique.');order.captureEntry?.();order.clicked=true;};
   try{
    if(c.canvasSelector){await c.frame.evaluate(canvasControlBridge,{action:'passthrough-on'});try{before();await c.frame.locator(c.canvasSelector).click({position:c.positions[order.side],timeout:500,noWaitAfter:true});}finally{await c.frame.evaluate(canvasControlBridge,{action:'passthrough-off'}).catch(()=>{});}}
    else{before();await c.frame.locator(order.side==='CALL'?c.callSelector:c.putSelector).click({timeout:500,noWaitAfter:true});}
    await sent;
   }finally{if(this.attempt===attempt)this.attempt=null;}
  }).catch(error=>{attempt.reject(error);throw error;});
  this.clickQueue=click.catch(()=>{});
  try{await click;return await confirmation;}finally{clearTimeout(timer);}
 }

 observe(provider,frame,direction){
  if(!isExecutionFrame(frame))return;
  const name=String(frame?.msg?.name||frame?.name||'').toLowerCase();
  const body=frame?.msg?.body??frame?.msg??frame?.body;
  const rid=frame?.request_id==null?null:String(frame.request_id);
  const a=direction==='page-out'?this.attempt:this.awaiting.get(provider+'|'+rid);
  if(direction==='page-out'){
   if(!/(?:open-option|place-digital-option|buyv3)$/.test(name))return;
   const outboundKey=provider+'|'+rid;if(this.outboundSeen.has(outboundKey))return;this.outboundSeen.add(outboundKey);if(this.outboundSeen.size>4096)this.outboundSeen.delete(this.outboundSeen.values().next().value);
   if(!a||a.provider!==provider){this.onUnexpectedOrder();return;}
   if(a.requestId===rid)return;
   const account=body?.user_balance_id??body?.balance_id;
   const value=body?.price??body?.amount;
   const directionSide=({call:'CALL',put:'PUT',buy:'CALL',sell:'PUT'})[String(body?.direction||body?.action||'').toLowerCase()];
   const active=body?.active_id??body?.active;
   if(!rid||!finite(value)||Math.abs(Number(value)-a.order.amount)>0.000001||
    (directionSide&&directionSide!==a.order.side)||(active!=null&&Number(active)!==Number(a.order.activeId))||(account!=null&&a.order.accountId!=null&&String(account)!==String(a.order.accountId))){a.reject(Error('Comando da corretora divergiu da entrada programada.'));return;}
   if(account!=null)a.order.accountId=String(account);
   a.requestId=rid;this.awaiting.set(provider+'|'+rid,a);if(this.awaiting.size>2048)this.awaiting.delete(this.awaiting.keys().next().value);this.onSent(rid,a.order.id);a.sent?.();return;
  }
  if(direction!=='page-in')return;
  if(a&&provider===a.provider&&rid&&rid===a.requestId){
   const id=body&&typeof body==='object'?(body.id??body.option_id??body.position_id??body.order_id):finite(body)?body:null;
   const failed=body?.isSuccessful===false||body?.success===false||body?.error||name==='error';
   if(failed){this.awaiting.delete(provider+'|'+rid);this.onRejected({provider,requestId:rid,localId:a.order.id});a.reject(Object.assign(Error('Ordem rejeitada pela corretora.'),{brokerRejected:true}));return;}
   if(id!=null&&['string','number'].includes(typeof id)&&String(id)!=='0'&&String(id)!=='-1'){
    const result={accepted:true,requestId:rid,orderId:String(id),accountId:a.order.accountId??null,localId:a.order.id};
    const opening=body?.open_price??body?.open_quote;
    if(finite(opening)&&Number(opening)>0)result.entryPrice=Number(opening);
    const expires=body?.expiration_time??body?.expired;
    if(finite(expires))result.exitAt=Number(expires)<1e12?Number(expires)*1000:Number(expires);
    this.orders.set(provider+'|'+id,{...a.order,provider,orderId:String(id)});
    if(this.orders.size>2048)this.orders.delete(this.orders.keys().next().value);
    this.awaiting.delete(provider+'|'+rid);
    this.onAccepted({...result,provider});a.resolve(result);
   }
  }
  if(!closingKind(frame))return;
  // Finish every identified child contained in a batched broker response.
  for(const [key,known] of [...this.orders]){
   if(known.provider!==provider)continue;
   const result=settlementFromFrame(provider,frame,known);
   if(result){this.orders.delete(key);this.onSettlement(result);}
  }
 }
}
