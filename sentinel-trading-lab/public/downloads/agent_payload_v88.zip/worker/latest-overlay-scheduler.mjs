// Full nested DOM reconstruction is deliberately infrequent. The 250ms clock\n// is native to the browser; analyst CALL/PUT transitions remain urgent.\n// Protect the broker chart: at most one overlay update in flight, coalesce
// superseded frames, and give the page breathing room after a slow render.
// There must never be a catch-up loop when Playwright/page.evaluate stalls.
export class LatestOverlayScheduler{
  constructor(update,{minIntervalMs=6000,slowThresholdMs=800,slowCooldownMs=8000,isCriticalBusy=null}={}){
    this.update=update;this.isCriticalBusy=typeof isCriticalBusy==='function'?isCriticalBusy:null;
    this.pending=null;this.running=false;this.errors=0;
    this.minIntervalMs=minIntervalMs;this.slowThresholdMs=slowThresholdMs;
    this.slowCooldownMs=slowCooldownMs;this.nextAllowedAt=0;this.timer=null;
    this.renderCount=0;this.slowCount=0;this.lastRenderMs=0;this.averageRenderMs=0;this.coalescedFrames=0;
    this.lastCompleteAt=0;this.urgentRenderCount=0;
    this.lastQueueDelayMs=0;this.maxQueueDelayMs=0;this.lastUrgentDeliveryMs=null;
  }
  publish(provider,data,{urgent=false}={}){
    if(this.pending)this.coalescedFrames++;
    // Preserve priority when an updated quote supersedes a pending CALL/PUT.
    this.pending={provider,data,urgent:urgent===true||this.pending?.urgent===true,
      queuedAt:this.pending?.urgent===true&&urgent!==true?this.pending.queuedAt:Date.now()};
    this.schedule();
  }
  schedule(){
    if(this.running||!this.pending)return;
    // Routine cosmetic refreshes are less frequent so they do not occupy
    // the broker's rendering queue. An actual decision transition bypasses
    // the normal and slow-render cooldown immediately, without another timer
    // or a second independent analysis. Never interrupt an active evaluate.
    if(this.timer){
      if(!this.pending.urgent)return;
      clearTimeout(this.timer);this.timer=null;
    }
    const readyAt=this.pending.urgent?
      Math.max(Date.now(),this.lastCompleteAt+50):this.nextAllowedAt;
    const delay=Math.max(0,readyAt-Date.now());
    this.timer=setTimeout(()=>{this.timer=null;void this.flush()},delay);
    this.timer.unref?.();
  }
  async flush(){
    if(this.running||!this.pending)return;
    // Don't rebuild the broker's heavy overlay DOM during a physical click.
    // Retain only the latest coalesced frame, not another data poll.
    if(this.isCriticalBusy?.()){
      this.timer=setTimeout(()=>{this.timer=null;void this.flush()},250);
      this.timer.unref?.();return;
    }
    this.running=true;
    const frame=this.pending;this.pending=null;
    const began=Date.now();
    this.lastQueueDelayMs=Math.max(0,began-Number(frame.queuedAt||began));
    this.maxQueueDelayMs=Math.max(this.maxQueueDelayMs,this.lastQueueDelayMs);
    try{await this.update(frame.provider,frame.data)}
    catch{this.errors++}
    finally{
      const elapsed=Date.now()-began,slow=elapsed>=this.slowThresholdMs;
      this.renderCount++;this.lastRenderMs=elapsed;
      if(frame.urgent){this.urgentRenderCount++;
        this.lastUrgentDeliveryMs=Math.max(0,Date.now()-Number(frame.queuedAt||began));}
      this.lastCompleteAt=Date.now();
      this.averageRenderMs=Math.round(this.averageRenderMs?this.averageRenderMs*.8+elapsed*.2:elapsed);
      if(slow)this.slowCount++;
      this.nextAllowedAt=Date.now()+(slow?this.slowCooldownMs:this.minIntervalMs);
      this.running=false;
      this.schedule();
    }
  }
  metrics(){return{
    lastRenderMs:this.lastRenderMs,averageRenderMs:this.averageRenderMs,
    renderCount:this.renderCount,slowCount:this.slowCount,urgentRenderCount:this.urgentRenderCount,
    coalescedFrames:this.coalescedFrames,errors:this.errors,
    lastQueueDelayMs:this.lastQueueDelayMs,maxQueueDelayMs:this.maxQueueDelayMs,
    lastUrgentDeliveryMs:this.lastUrgentDeliveryMs,
    pending:this.pending!=null,running:this.running
  }}
}
