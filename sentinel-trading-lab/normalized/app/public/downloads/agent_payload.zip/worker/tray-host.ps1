$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$node = Join-Path $root '.sentinel-runtime\node.exe'
$manager = Join-Path $root 'worker\agent-manager.mjs'
$iconPath = Join-Path $root 'worker\sentinel.ico'
$exitMarker = Join-Path $root 'worker\data\agent.exit'
$site = 'https://sentinel-trading-lab.vercel.app'
$managerHealth = 'http://127.0.0.1:8788/health'
$agentEnabled = $true

# Mantém o controlador/ícone disponível após novo login do Windows.
try {
  $runKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'
  $runCmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$($MyInvocation.MyCommand.Path)`""
  New-Item -Path $runKey -Force | Out-Null
  Set-ItemProperty -Path $runKey -Name 'SentinelTradingLab' -Value $runCmd -Force
} catch {}

$created = $false
$mutex = New-Object System.Threading.Mutex($true, 'Local\SentinelTradingLabTrayV860', [ref]$created)
if (-not $created) { exit 0 }
if (Test-Path $exitMarker) { Remove-Item $exitMarker -Force -ErrorAction SilentlyContinue }

function Start-Manager {
  try {
    if (Test-Path $exitMarker) { Remove-Item $exitMarker -Force -ErrorAction SilentlyContinue }
    $env:SENTINEL_WORKER_HOST = '127.0.0.1'
    $env:SENTINEL_WORKER_PORT = '8787'
    $env:SENTINEL_MANAGER_PORT = '8788'
    $env:SENTINEL_ALLOWED_ORIGINS = 'https://sentinel-trading-lab.vercel.app,https://sentinel-trading-lab-iguassu-shop.vercel.app'
    Start-Process -FilePath $node -ArgumentList @($manager) -WorkingDirectory $root -WindowStyle Hidden | Out-Null
  } catch {}
}
function Get-Health { try { return Invoke-RestMethod -UseBasicParsing $managerHealth -TimeoutSec 1 } catch { return $null } }
function Stop-Agent { try { Invoke-RestMethod -UseBasicParsing 'http://127.0.0.1:8788/exit' -Method Post -TimeoutSec 2 | Out-Null } catch {} }
function Restart-Worker { try { return Invoke-RestMethod -UseBasicParsing 'http://127.0.0.1:8788/restart' -Method Post -TimeoutSec 8 } catch { return $null } }
function Start-Worker { try { return Invoke-RestMethod -UseBasicParsing 'http://127.0.0.1:8788/start' -Method Post -TimeoutSec 8 } catch { return $null } }

if (-not (Get-Health)) { Start-Manager }

$notify = New-Object System.Windows.Forms.NotifyIcon
try { $notify.Icon = New-Object System.Drawing.Icon($iconPath) } catch { $notify.Icon = [System.Drawing.SystemIcons]::Application }
$notify.Text = 'Sentinel Agent V8.6'
$notify.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$statusItem = New-Object System.Windows.Forms.ToolStripMenuItem
$statusItem.Text = 'Status: iniciando...'; $statusItem.Enabled = $false
$openItem = New-Object System.Windows.Forms.ToolStripMenuItem
$openItem.Text = 'Abrir Sentinel'
$startItem = New-Object System.Windows.Forms.ToolStripMenuItem
$startItem.Text = 'Ligar Agent'
$stopItem = New-Object System.Windows.Forms.ToolStripMenuItem
$stopItem.Text = 'Desligar Agent'
$restartAgentItem = New-Object System.Windows.Forms.ToolStripMenuItem
$restartAgentItem.Text = 'Reiniciar Agent'
$restartWorkerItem = New-Object System.Windows.Forms.ToolStripMenuItem
$restartWorkerItem.Text = 'Reiniciar Worker'
$pairItem = New-Object System.Windows.Forms.ToolStripMenuItem
$pairItem.Text = 'Vincular conta: aguardando...'
$pairItem.Enabled = $false
[void]$menu.Items.Add($statusItem)
[void]$menu.Items.Add('-')
[void]$menu.Items.Add($openItem)
[void]$menu.Items.Add($pairItem)
[void]$menu.Items.Add($startItem)
[void]$menu.Items.Add($stopItem)
[void]$menu.Items.Add($restartAgentItem)
[void]$menu.Items.Add($restartWorkerItem)
$notify.ContextMenuStrip = $menu

$openItem.Add_Click({ Start-Process $site })
$startItem.Add_Click({
  $script:agentEnabled = $true
  $statusItem.Text = 'Status: ligando Agent...'
  if (-not (Get-Health)) { Start-Manager; Start-Sleep -Milliseconds 600 }
  Start-Worker | Out-Null
})
$stopItem.Add_Click({
  $script:agentEnabled = $false
  $statusItem.Text = 'Status: Agent desligado pelo usuário'
  Stop-Agent
})
$restartAgentItem.Add_Click({
  $script:agentEnabled = $true
  $statusItem.Text = 'Status: reiniciando Agent...'
  Stop-Agent
  Start-Sleep -Milliseconds 700
  Start-Manager
})
$restartWorkerItem.Add_Click({
  $script:agentEnabled = $true
  $statusItem.Text = 'Status: reiniciando Worker...'
  if (-not (Get-Health)) { Start-Manager; Start-Sleep -Milliseconds 600 }
  Restart-Worker | Out-Null
})
$pairItem.Add_Click({ if ($pairItem.Tag) { [System.Windows.Forms.Clipboard]::SetText([string]$pairItem.Tag); Start-Process ($site + '/?pair=' + [uri]::EscapeDataString([string]$pairItem.Tag)) } })
$notify.Add_DoubleClick({ Start-Process $site })

$failCount = 0
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 2500
$timer.Add_Tick({
  if (Test-Path $exitMarker) { Remove-Item $exitMarker -Force -ErrorAction SilentlyContinue; $script:agentEnabled = $false }
  $h = Get-Health
  try {
    $ri = Invoke-RestMethod -UseBasicParsing 'http://127.0.0.1:8787/remote-info' -TimeoutSec 1
    if ($ri -and $ri.paired) { $pairItem.Text = 'Conta vinculada'; $pairItem.Enabled = $false; $pairItem.Tag = $null }
    elseif ($ri -and $ri.pairingCode) { $pairItem.Text = 'Vincular conta: ' + $ri.pairingCode; $pairItem.Enabled = $true; $pairItem.Tag = $ri.pairingCode }
    else { $pairItem.Text = 'Vincular conta: aguardando...'; $pairItem.Enabled = $false; $pairItem.Tag = $null }
  } catch {}
  if ($h -and $h.ok) {
    $failCount = 0
    $script:agentEnabled = $true
    if ($h.workerHealthy) {
      $statusItem.Text = 'Status: Agent + Worker ONLINE'
      $notify.Text = 'Sentinel Agent - ONLINE'
    } elseif ($h.workerEnabled -eq $false) {
      $statusItem.Text = 'Status: Agent ligado / Worker pausado'
      $notify.Text = 'Sentinel Agent - Worker pausado'
    } else {
      $statusItem.Text = 'Status: Agent online / Worker iniciando'
      $notify.Text = 'Sentinel Agent - Worker iniciando'
    }
  } else {
    if (-not $script:agentEnabled) {
      $statusItem.Text = 'Status: Agent DESLIGADO'
      $notify.Text = 'Sentinel Agent - DESLIGADO'
      return
    }
    $failCount++
    $statusItem.Text = 'Status: recuperando Agent...'
    $notify.Text = 'Sentinel Agent - recuperando'
    if ($failCount -ge 2) { Start-Manager; $failCount = 0 }
  }
})
$timer.Start()

$notify.BalloonTipTitle = 'Sentinel Agent'
$notify.BalloonTipText = 'Controlador ativo na bandeja. Botão direito: ligar, desligar, reiniciar ou abrir o Sentinel.'
$notify.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
$notify.ShowBalloonTip(4500)

[System.Windows.Forms.Application]::Run()
$timer.Stop(); $notify.Visible = $false; $notify.Dispose()
try { $mutex.ReleaseMutex() } catch {}
$mutex.Dispose()
